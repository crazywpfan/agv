<?php
namespace agv\Staff ;

class Position {
	
	public $id ;
	public $title ;
	
	public function __construct ( $a ) {
	
	}
}