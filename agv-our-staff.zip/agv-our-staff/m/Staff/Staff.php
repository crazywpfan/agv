<?php
namespace agv ;

class Staff{
	private $id ;
    public $name;
    public $image;
    public $position;

    public function __construct( $a ){
        if( isset( $a['id'] ) ){
            $this->name = get_option( name( 'staff_id_' . $id ) , $a['id'] ) ;
        }
        $this->create($a);
    }

    private function create( $id ){
        switch( $id ){
            case 1:
                $this->name = 'Андрей' ;
                $this->image['url'] = 'http://www.uni-regensburg.de/Fakultaeten/phil_Fak_II/Psychologie/Psy_II/beautycheck/english/durchschnittsgesichter/m(01-32)_gr.jpg' ;
                $this->position = 'Консултант' ;
                break;
            case 2:
                $this->name = 'Валентина' ;
                $this->image['url'] = 'http://starozagorskinovini.com/news//images/Politika/BSP_Valentina_Boneva.jpg' ;
                $this->position = 'Експерт' ;
                break;
            case 3:
                $this->name = 'Младен' ;
                $this->image['url'] = 'http://cache1.bgfermer.bg/Images/cache/595/Image_4739595_2_0.jpg' ;
                $this->position = 'Стилист' ;
                break;
        }
    }
} #class AlViOurStaffPerson