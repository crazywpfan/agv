<?php
namespace agv ;

class UseCase {
    public function __construct( $uc, $obj = false ){
        $f = '_' . AGV_PREFIX . $uc ;
        require_once( AGV_C . $uc . '.php' ) ; # /c/ save_post .php
        if ( $obj ) {
            $f( $obj ) ; # agv_our_staff_$uc( $obj )
        } else {
            $f();
        }
    }	
}