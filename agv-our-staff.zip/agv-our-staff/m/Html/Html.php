<?php
namespace agv ;

class Html{
	
    public function __construct( $a = FALSE ){

    }

    public function get( $a ){
        if( isset( $a['dir'] ) ){
            return file_get_contents( AGV_V . 'html' .DIRECTORY_SEPARATOR . $a[ 'dir' ] . DIRECTORY_SEPARATOR . $a[ 'file' ] . '.html' ) ;
        }
        return file_get_contents( AGV_V . 'html' .DIRECTORY_SEPARATOR . $a . DIRECTORY_SEPARATOR . $a . '.html' ) ;
    }

}