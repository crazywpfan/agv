<?php
namespace agv ;

class Form{
	/*
	$Form = new \agv\Form([
		'name' => 'form_name' ,
		'action' => 'form_action' 
		'method' => 'POST'
	]) ;
	$Form->add( new \agv\form\Select( [
		'name' => 'select_name'
	] ) ) ;
	$Form->show() ;
	*/
	private $name ; # <form name = ' $name ' >
	private $action ; # url
	private $method ; # post, get
	private $form ; # съдържа готовата форма
	private $els ; # елементите, които да се добавят
	
	public function __construct( $a = array() ){
		$this->name = '' ;
		$this->action = '' ;
		$this->method = 'POST' ;
		$this->els = array() ;
		
		if( isset ( $a[ 'name' ] ) ){
			$this->name = $a[ 'name' ] ;
		}
		
		if( isset( $a[ 'action' ]) ){
			$this->action = $a[ 'action' ] ;
		}
		
		if( isset( $a[ 'method' ] ) ){
				$this->method = $a[ 'method' ] ;
		}
		
	} # __construct

	public function add( $el ){
		/* 	el = array(
					html
					name - съвпада с $_POST 
					position
					type - select, radio, textarea, etc.
				) ;
		*/
		$this->els[] = $el[ 'html' ] ;
	} # add
	
	public function show(){
		$this->form = '' ;
		$this->form .= "<form name = ' $this->name' action = '$this->action' method = '$this->method' > " ;
		if ( $this->els[0] ){
			foreach ( $this->els as $el ){
				$this->form .= $el ;
			}
		}
		$this->form .= '</form>' ;
		return $this->form ;
	} # $this->show()
	
} #class Form