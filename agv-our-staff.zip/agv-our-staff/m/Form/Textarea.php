<?php
namespace agv\Form ;

class Textarea{
	
	private $label ;
	private $text ;
	private $text_position ; # преди или след textarea
	private $id ;
	private $class ;
	private $name ;
	private $placeholder ;
	private $content ;
	
	
	
	/*
	return
	<label >
		<p>
			$this->text
		</p>
		<textarea 
			name = ' $this->name ' 
			id = ' $this->id '
			class = ' $this->class '
			placeholder = ' $this->placeholder '
		>
			$this->content
		</textarea>
	</label>
	*/
	public function __construct ( $a = FALSE ){
		
	}
	
	

}