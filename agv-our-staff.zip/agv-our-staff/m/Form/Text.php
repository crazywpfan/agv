<?php
namespace agv\Form ;
class Text{
	
	public function __construct( $a = FALSE ){
	
	}
	
}