<?php
namespace agv\Form ;

class Select{
	private $name ;
	private $id ;
	private $class ;
	private $title ;
	private $els ; # масив с елементите
	
	public function __construct( $a = FALSE){
		if( $a['name'] ){
			$this->name = $a['name'] ;
		}
		if( $a['id'] ){
			$this->id = $a['id'] ;
		}
		if( $a['class'] ){
			$this->class = $a['class'] ;
		}
		if( $a['title'] ){
			$this->title = $a['title'] ;
		}
	} # $this->__construct()
	
	public function add( $opt ){
		$this->els[] = $opt ;
	} # $this->add()
	
	public function show(){
		$s = " <select name = ' name( $this->name ) ' id = ' $this->id ' class = ' $this->class ' title = ' $this->title ' > " ;
			if( $this->els[0] ){
				foreach( $this->els as $e ){
					$s .= $e ;
				}
			}
		$s .= " </select> " ;
		return $s ;
	}
}