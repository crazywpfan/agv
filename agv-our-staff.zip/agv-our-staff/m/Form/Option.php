<?php
namespace agv\Form\Select ;
/*
@ example :
$Select = al('Form\Select' , [
	'name' => name()
]) ;
foreach ( $Staffs as $Staff ){
	$Select->add( $Option( [ 
		'value' => $Staff->id ,
		'text' => $Staff->name . ' / ' . $Staff->position
	 ] ) ) ;
}
*/
class Option{
	private $value ;
	private $text ;
	private $id ;
	private $class ;
	private $title ;
	
	public function __construct( $a = FALSE ){
		if( $a[ 'value' ]){
			if( $a[ 'text' ] ){
				$this->value = $a[ 'value' ] ;
				$this->text = $a[ 'text' ] ;
				if( $a['id'] ){
					$this->id = $a['id'] ;
				}
				if( $a['class'] ){
					$this->class = $a['class'] ;
				}
				if( $a['title'] ){
					$this->title = $a['title'] ;
				}
				return " <option id = ' $this->id ' class = ' $this->class ' title = ' $this->title ' value = ' $this->value ' > $this->text </option> " ;
			}
		}
	}
}