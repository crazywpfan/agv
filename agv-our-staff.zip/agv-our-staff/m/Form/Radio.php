<?php
namespace agv\Form ;
class Radio{
	
	public function __construct( $a = FALSE ){
	
	}
	
}