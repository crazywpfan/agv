<?php
namespace \agv\Form ;

class Checkbox{
	
	private $checked ;
	private $name ;
	private $id ;
	/*
		description : масив с всички id-та. преди да се добави
		но
	*/
	private static $ids ; # 
	
	public function __construct( $a = FALSE ) {
		if( 
			$a[ 'checked' ]
			&& (int)$a[ 'checked' ] > 0
		) {
			$this->checked = $a [ 'checked' ] ;
		}
		
		if ( $a[ 'name' ] ) {
			$this->name = $a [ 'name' ] ;
		}
	}
	
}