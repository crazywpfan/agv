<?php
namespace agv\System ;

class IDs{
	
	private static $instance ; 
	private static $ids ;
	
	private function __construct(){
		self::$ids = array() ;
	}
	
	public static function getInstance(){
		if( ! self::$instance ){
			self::$instance = $this ;
		}
		return self::$instance ;
	}
	
	public static function add( $id ){
		if( ! self::$ids[ $id ] ) {
			self::$ids[ $id ] = $id ;
			return true ;
		}
		return al( 'Error' , [
			'text' => " Това id ( $id )  е вече зададено "
		] ) ;
	}
}