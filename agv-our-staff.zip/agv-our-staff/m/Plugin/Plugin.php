<?php
namespace agv ;

class Plugin {
	
    public $title ;
    public $logo ;

    public function __construct ( $a = FALSE ) {
        $this->title = 'Our Staff' ;
        $this->logo['url'] = 'https://www.themexpert.com/images/wordpress-logo.png';
    }
	
}