<?php
namespace agv ;

class Brand {
	
    public $id ;
    public $name ;
    public $address ;

    public function __construct( $a = FALSE ) {
        $this->name = "AGV" ;
    }
	
}