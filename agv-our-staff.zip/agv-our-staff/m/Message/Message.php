<?php
namespace agv ;

class Message{
    private $post_id ;
    public $id ;
    public $class ;
    public $title ;
    public $text ;
    public $type ;
    public $placeholder ;
	
    public function __construct( $post_id = FALSE ){
        $this->create( $post_id );
        $this->text = get_post_meta( $post_id , name( 'message_text' ) )[0] ;
        return;
        if( 
            $post_id 
            && (int)$post_id > 0
        ){
            $this->post_id = (int)$post_id ;
            $this->id = get_post_meta( $post_id , name( 'message_id' ) )[0] ;
            $this->class = get_post_meta( $post_id , name( 'message_class' ) )[0] ;
            $this->title = get_post_meta( $post_id , name( 'message_title' ) )[0] ;
            $this->type = al( 'Message\Type' , $this->id ) ;
            get_post_meta( $post_id , name( 'message_type' ) )[0] ;
            $this->text = get_post_meta( $post_id , name( 'message_text' ) )[0] ;
            $this->placeholder = "Empty for delete";
        }
    }

    private function create( $id ){
        switch( $id ){
            case 1:
                $this->id = 1 ;
                $this->class = 'advice' ;
                $this->title = 'Съвет' ;
                break;
            case 2:
                $this->id = 2 ;
                $this->class = 'important' ;
                $this->title = 'Важно' ;
                break;
            case 3:
                $this->id = 3 ;
                $this->class = 'warning' ;
                $this->title = 'Внимание' ;
                break;
        }
    }
}