<?php
namespace agv\Message ;

class Type{
	
    private $id ;
    public $class ;
    public $title ;

    public function __construct( $a = FALSE ) {
        if( 
            $a[ 'id' ]
            && (int)$a[ 'id' ] > 0
        ){
            $this->id = $a[ 'id' ] ;
        }
        $this->class = get_option ( name( 'message_' . $this->id . '_class' ) ) ;
        $this->title = get_option ( name( 'message_' . $this->id . '_title' ) ) ;
    }
}