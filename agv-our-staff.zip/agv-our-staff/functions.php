<?php
/******************************
Съдържание :
al( $Class , $prop = GALSE)
name( $name )
agv_psc( $a )

*****************************/

/******************************
	@ example al( 'Message', 1 ) 
	/m/Message/Message.php -тук папката и класа съвпадат
	new agv\Message()
	
	@ example al( 'Form\Select', 2 ) 
	/m/Form/Select.php
	new agv\Form\Select()
	
	@ example al( 'Form\Select\Option', 3)
	/m/Form/Option.php
	new agv\Form\Select\Option()
*/

function al( $Class, $prop = FALSE ){
    $Class = trim( $Class , "\\"  ) ;
    $a = explode("\\", $Class );
    if($a[0]){
        # al( 'Message', 1 )
        if( ! $a[1] ){
            $file = AGV_M . ucfirst  ( $a[0] ) . DIRECTORY_SEPARATOR . ucfirst  ( $a[0] ) . '.php';
        } 
        # al( 'Form\Select', 2 ) 
        elseif( ! $a[2] ){
            $file = AGV_M . ucfirst  ( $a[0] ) . DIRECTORY_SEPARATOR . ucfirst  ( $a[1] ) . '.php' ;
        }
        # al( 'Form\Select\Option', 3)
        else {
            $file = AGV_M . ucfirst  ( $a[0] ) . DIRECTORY_SEPARATOR . ucfirst  ( $a[2] ) . '.php';
        }
        if( file_exists($file) ){
            require_once $file;
            $Class = 'agv\\' . $Class ;
            if($prop){
                return new $Class($prop);
            }
            return new $Class();
        }
    }
}

/******************************
@ example 
$Select = al( 'Form\Select' , [
	'name' => name( 'staff_position' )
	agv_our_staff_ staff_position
] ) ;
*/

function name( $name ){
	return AGV_PREFIX . $name ;
}

/******************************
prepare shortcodes
@ $a масив с елементите&#a
@ return array 
*/

function agv_psc( $a ){
    # pre
    if( ! $a ){
        return ;
    }
    $_ = array();
    foreach( $a as $v ){
        $_[] = '{{' . $v . '}}';
    }
    return $_;
}