Схема на системата :

		plugin-file.php
			/\
		    ll 
		init.php
			/\
		    ll 
		/m/UseCases.php
		functions.php
		usecases.php

plugin-file.php :
	съдържа блока с данните на плъгина
	дефинира префикса на плъгина
	
init.php
	дефинира главните УНИВЕРСАЛНИ стойности
	включва УНИВЕРСАЛНИТЕ файловете
	създава основните УНИВЕРСАЛНИ класове
	
usecases.php
	задава ползваните hooks
	задава съответните им agv\UseCase
	
1 ----- 1
the_content  /v/html/the_content/the_content.html

1 ----- *
admin_menu /v/html/admin_menu/home_page.html
																			/about.html

Плъгина започва работа в съответния контролер в папка ”с”