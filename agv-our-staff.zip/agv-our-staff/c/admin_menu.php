<?php
function _agv_our_staff_admin_menu(){
    //create custom top-level menu
    add_menu_page( 
        'Our staff',
        'Our staff',
        'manage_options', 
        __FILE__, 
        'agv_our_staff_home_page',
        plugins_url( '/images/wp-icon.png', __FILE__ ) 
    );

        //create submenu items
        add_submenu_page( 
            __FILE__, 
            'About My Plugin',
            'About', 
            'manage_options',
            __FILE__.'_about', 
            'agv_our_staff_about_page'
        );
        add_submenu_page( 
            __FILE__,
            'Help with My Plugin', 
            'Help', 
            'manage_options',
            __FILE__.'_help', 
            'boj_menuexample_help_page'
        );
        add_submenu_page( 
            __FILE__, 
            'Uninstall My Plugin', 
            'Uninstall', 
            'manage_options',
            __FILE__.'_uninstall', 
            'boj_menuexample_uninstall_page'
        );
}

	function agv_our_staff_home_page(){
            $Html = al( 'Html') ;
            echo $Html->get( ['dir' => 'admin_menu', 'file' => 'home_page' ] ) ;
	}
	function agv_our_staff_about_page(){
            $Html = al( 'Html') ;
            echo $Html->get( ['dir' => 'admin_menu', 'file' => 'about_page' ] ) ;
	}