<?php
function _agv_our_staff_the_content( $content ){

    /* pre-conditions */
    if ( 
        ! get_the_ID() 
        || ! is_single() 
        || ! get_post_meta( get_the_ID() , 'agv_our_staff_message_text' )
    ){
        return FALSE ;
    }

    /* Classes , variables */
    $post_id = get_the_ID() ;
    $Html = al( 'Html' ) ;
    $Message = al('Message', $post_id);
    $Staff = al('Staff', (int)get_post_meta( $post_id , 'agv_our_staff_staff_id' )[0] );
    $Brand = al('Brand');
    $Plugin = al('Plugin');
    $post_id = get_the_ID() ;
	
    /* init shortcodes */
    $sc = array(
        'Message-class' ,
        'Message-title' ,
        'Plugin-logo-url' ,
        'Brand-name' ,
        'Plugin-title' ,
        'Staff-image-url' ,
        'Staff-name' ,
        'Staff-position' ,
        'Message-text'
    );
    $opt = array(
        $Message->class ,
        $Message->class ,
        $Plugin->logo[ 'url' ] ,
        $Brand->name ,
        $Plugin->title ,
        $Staff->image[ 'url' ] ,
        $Staff->name ,
        $Staff->position ,
        $Message->text
    );

    /* return */
    echo $content . str_replace(agv_psc( $sc ), $opt, $Html->get( 'the_content' ) ) ;
}