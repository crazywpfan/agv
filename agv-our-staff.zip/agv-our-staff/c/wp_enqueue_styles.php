<?php
function _agv_our_staff_wp_enqueue_styles(){
    wp_enqueue_style( 'bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' ); 
    wp_enqueue_style( 'my-style', get_template_directory_uri() . '/style.css');
}