<?php
function _agv_our_staff_save_post( $post_id ){
    #pre
    if ( ! is_admin() ) {
            return;
    }
    ###
    if( 
        isset( $_POST['agv_our_staff_message_text'] ) 
        && trim( $_POST['agv_our_staff_message_text'] ) != ''
    ){
        if( 
            isset( $_POST['agv_our_staff_staff_id'] ) 
            && (int)$_POST['agv_our_staff_staff_id'] > 0 
        ){
            if( 
                isset( $_POST['agv_our_staff_message_type_id'] )
                && (int)$_POST['agv_our_staff_message_type_id'] > 0
            ){
                if( 
                    isset( $_POST['agv_our_staff_message_position'] ) 
                    && (int)$_POST['agv_our_staff_message_position'] > 0
                ){
                    $post_id = (int)$_POST['post_ID'];
                    update_post_meta( $post_id, 'agv_our_staff_message_text', esc_textarea( $_POST['agv_our_staff_message_text'] )  );
                    update_post_meta( $post_id, 'agv_our_staff_staff_id', (int) $_POST['agv_our_staff_staff_id']   );
                    update_post_meta( $post_id, 'agv_our_staff_message_type_id', (int) $_POST['agv_our_staff_message_type_id']  );
                    update_post_meta( $post_id, 'agv_our_staff_message_position', (int) $_POST['agv_our_staff_message_position']  );
                } else {

                }
            } else {

            }
        } else{

        }
    } else{

    }
}