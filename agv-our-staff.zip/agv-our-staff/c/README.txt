/* pre-conditions */
/* Classes , variables */
/* init */
/* return */

Ако има нужда се дописват помощни функции под основната