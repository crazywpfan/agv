<?php
function _agv_our_staff_delete_post(){
	
}