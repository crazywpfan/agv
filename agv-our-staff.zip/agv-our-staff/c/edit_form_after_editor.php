р<?php
function _agv_our_staff_edit_form_after_editor(){

    /* pre-conditions */
    if ( ! is_admin() ){
            return;
    }
    if( 
        isset( $_GET['post'])
        && (int)$_GET['post'] > 0
    ){
        $post_id = (int)$_GET['post'] ;
    }

    if( 
        (int)get_post_meta( $post_id , 'agv_our_staff_staff_id' )[0] > 0 
    ){
        $Staff = al( 'Staff', (int)get_post_meta( $post_id , 'agv_our_staff_staff_id' )[0] ) ;
    }

    /* Classes , variables */
    $Html = al( 'Html' );
    $Message = al( 'Message' , $post_id ) ;
    $Plugin = al( 'Plugin');

    /* init shortcodes */
    $sc = [
        'Plugin-logo-url',
        'Plugin-title',
        'Message-text-placeholder',
        'Message-text',
        'select-staff-id',
        'select-message-type-id',
        'checkbox-message-position'
    ] ;
    $opt = [
        $Plugin->logo['logo'] ,
        $Plugin->title ,
        $Message->placeholder ,
        $Message->text ,
        select_staff_id(['post_id' => $post_id ]) ,
        select_message_type_id( array('message_type_id' => (int)get_post_meta( $post_id , 'agv_our_staff_message_type_id' )[0] ) ) ,
        checkbox_message_position()
    ] ;
	
    /* return */
    echo str_replace( agv_psc( $sc ), $opt, $Html->get( 'edit_form_after_editor' ) ) ;
}

    function select_staff_id( $a = false ){
        $options = '';
        if( 
            isset( $a['post_id'] )
            && (int)$a['post_id'] > 0
        ){
            $staff_id = (int)get_post_meta( $a['post_id'] , 'agv_our_staff_staff_id' )[0] ;
        }
        for( $i = 1; $i < 4; $i++){
            $Staff = al('Staff', $i) ; 
            $sel = '';
            if( $i === $staff_id){
                    $sel = "selected = 'selected' " ;
            }
            $options .= "<option value='$i' $sel> $Staff->name / $Staff->position </option>" ;
        }
        return $options ;
    }
    
    function select_message_type_id( $a = false ){
        $options = '';
        for( $i = 1; $i < 4; $i++){
            $Message = al('Message', $i) ; 
            $sel = '';
            if( $i == $a['message_type_id'] ){
                $sel = "selected = 'selected' " ;
            }
            $options .= "<option value='$Message->id' $sel> $Message->title </option>" ;
        }
        return $options ;
    }
    
    function checkbox_message_position(){
        $d = <<<D
        <input type='radio' name='agv_our_staff_message_position' value='1'> Преди 
        <input type='radio' name='agv_our_staff_message_position' value='2' checked> След
D;
        return $d;
   }