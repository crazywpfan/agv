<?php
function _agv_our_staff_wp_enqueue_scripts(){
	wp_enqueue_script( 'jquery', '//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js', array('jquery'), '1.9.1', true); 
	// we need the jquery library for bootsrap js to function 
	wp_enqueue_script( 'bootstrap-js', '//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js', array('jquery'), true);
	 // all the bootstrap javascript goodness
	wp_enqueue_script( 'ui',  plugin_dir_url( __FILE__) . 'v/js/ui.js' ); 
	wp_enqueue_style( 'bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' ); 
	wp_enqueue_style( 'style',  plugin_dir_url() . 'agv-our-staff/v/css/style.css' ); 
}