/**
alert( 'work' ) ;
/**/
jQuery(document).ready(function($) {
	// var divs = $(".Person-w") ;
	// divs.hide() ;
	// var Message = $(".container") ;
} );

/**/
alert( ' Message ' ) ;
/**/
