<?php
/*
ЗАКОН
	Този файл се ползва само и единствено за :
	* задаване на константи
	* включване на файловете нужни на системата да сработи
	* задаване на системните класове

тъй като този файл е абсолютно задължителен за абсолютно
всички плъгини, то той по никакъв начин не би трябвало
да се променя като концепция
*/

define ( 'AGV_INIT_VER' , '1.1' ) ;
define ( 'AGV_M' , rtrim( plugin_dir_path( __FILE__ ) , '/' ) . DIRECTORY_SEPARATOR . 'm' . DIRECTORY_SEPARATOR ) ;
define ( 'AGV_V' , rtrim( plugin_dir_path( __FILE__ ) , '/' ) . DIRECTORY_SEPARATOR . 'v' . DIRECTORY_SEPARATOR) ;
define ( 'AGV_C' , rtrim( plugin_dir_path( __FILE__ ) , '/' ) . DIRECTORY_SEPARATOR . 'c' . DIRECTORY_SEPARATOR) ;

require_once( AGV_M . 'UseCase' . DIRECTORY_SEPARATOR . 'UseCase.php' );
require_once( 'functions.php' ) ;
require_once ( 'usecases.php' ) ;

//$IDs = al('System\IDs') ;