<?php
/*
Plugin name: AGV - Our staff
Plugin URI: http://agvsoft.pro/our-staff
Description: Създайте приятна атмосфера за вашите посетители.
Вашия екип обслужва гостите на сайта ви. Това става 
чрез съобщения
Version: 1.0
Author: AGV soft
Author URI: http://git.com/agvsoft/our-staff
License: GPLv2
*/
define ( 'AGV_PREFIX' , 'agv_our_staff_' );
require_once ( 'init.php' ) ;