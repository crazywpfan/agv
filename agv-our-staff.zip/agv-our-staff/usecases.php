<?php
/*
ЗАКОН
    В този файл се задават само и единствено куките,
    които ползва плъгина заедно с техните конкретни
    системни UseCases
*/
add_action('wp_enqueue_scripts', 'agv_our_staff_wp_enqueue_scripts' ); 
add_action('admin_enqueue_scripts' , 'agv_our_staff_admin_enqueue_scripts' );
add_action('wp_enqueue_styles', 'agv_our_staff_wp_enqueue_styles' );
add_action('admin_enqueue_styles', 'agv_our_staff_admin_enqueue_styles' );
add_action( 'admin_menu', 'agv_our_staff_admin_menu' );
add_action('save_post', 'agv_our_staff_save_post' );
add_action('delete_post', 'agv_our_staff_delete_post' );
add_action('the_content' , 'agv_our_staff_the_content' ) ;
add_action( 'edit_form_after_editor' , 'agv_our_staff_edit_form_after_editor' );

function agv_our_staff_wp_enqueue_scripts() {
	new \agv\UseCase( 'wp_enqueue_scripts' ) ;
}
function agv_our_staff_admin_enqueue_scripts(){
	new \agv\UseCase( 'admin_enqueue_scripts' ) ;
}
function agv_our_staff_wp_enqueue_styles() { 
	new \agv\UseCase( 'wp_enqueue_scripts' ) ;
} 
function agv_our_staff_admin_enqueue_styles(){
	new \agv\UseCase ( 'admin_enqueue_styles' ) ;
}
function agv_our_staff_admin_menu(){
	new \agv\UseCase ( 'admin_menu' ) ;
}
function agv_our_staff_save_post( $post_id ){
	new \agv\UseCase ( 'save_post' , $post_id) ;
}
function agv_our_staff_delete_post( $post_id ){
	new \agv\UseCase ( 'delete_post' , $post_id) ;
}
function agv_our_staff_the_content( $content ){
        new \agv\UseCase( 'the_content' , $content ) ;
}
function agv_our_staff_edit_form_after_editor(){
	new \agv\UseCase( 'edit_form_after_editor' ) ;
}